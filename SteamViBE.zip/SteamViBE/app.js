 let IconClick = document.getElementById("IconClick");
 let SearchDad  = document.getElementById("SearchDad");
 let SearchInput = document.getElementById("SearchInput");
 let InputSearch = document.getElementById("InputSearch");
 let CloseSearch = document.getElementById("CloseSearch");
 inputvelue1 = SearchInput.velue;
 IconClick.addEventListener("click", function()  {
   // SearchDad.style.left="570px";
   SearchDad.style.left="400px"
    IconClick.style.display="none";
    CloseSearch.style.fontSize="18px";
 })
 CloseSearch.addEventListener("click", function(){
   IconClick.style.display="block";
   CloseSearch.style.fontSize="0";
   SearchDad.style.left="-350px"
   InputSearch.style.borderRadius="15px";
   SearchInput.style.opacity="0";
 });
InputSearch.addEventListener('click', function(){
   SearchInput.style.opacity="1";
   SearchDad.style.left="570px";
   InputSearch.style.borderBottomLeftRadius="0";
   InputSearch.style.borderTopLeftRadius="0";
   InputSearch.style.borderBottomRightRadius="8px";
   InputSearch.style.borderTopRightRadius="8px";
    if(inputvelue1.length > 0) {
      inputvelue1.innerHtml="";
    }

})
